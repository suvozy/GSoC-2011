/*
** =========================================================================
** Copyright (c) 2010-2011  Immersion Corporation.  All rights reserved.
**                          Immersion Corporation Confidential and Proprietary
**
** File:
**     BouncingBallView.java
**
** Description: 
**     Sample Box2D drawing and physics code.
**
** =========================================================================
*/
package com.immersion.bouncingballsample;

import static android.hardware.SensorManager.SENSOR_DELAY_FASTEST;

import org.jbox2d.collision.AABB;
import org.jbox2d.collision.CircleDef;
import org.jbox2d.collision.PolygonDef;
import org.jbox2d.collision.PolygonShape;
import org.jbox2d.collision.ShapeType;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.World;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;

public class BouncingBallView extends View implements Runnable
{   
    Bitmap mBitmap;
    Canvas mCanvas;
    Bitmap mBall;
    
    private AABB worldAABB;             // physics world including walls
    private AABB worldAABBVisible;      // drawn world excluding walls
    private World world = null;
    Body ballBody;
    private float ballRadius = 0.7f;
    private Body[] wallBody;
    private float wallThickness = 1.0f;
    float drawWalls = 0.f;
    
    private int targetFPS = 60; 
    private float timeStepSec = (1.0f / targetFPS ); 
    private int iterations = 5;
    private float timeScale = 3.0f;
    
    private Vec2 gravity = new Vec2(0,0);
    
    private Handler handler = new Handler();
    private boolean isPaused = true;
    private SensorEventListener accelerometerListener = new SensorEventListener()
    {
        @Override
        public void onAccuracyChanged(Sensor arg0, int arg1) {}
        
        @Override
        public void onSensorChanged(SensorEvent sensorEvent)
        {
            gravity.x = -sensorEvent.values[0];
            gravity.y = -sensorEvent.values[1];
        }
    };

    public BouncingBallView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }
    
    public BouncingBallView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }
    
    protected void onSizeChanged(int width, int height, int widthOld, int heightOld)
    {
        mBitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.RGB_565);
        mCanvas = new Canvas(mBitmap);
    }
    
    public Body getBall()
    {
    	return ballBody;
    }
    
    /**
     * Release objects to avoid memory leaks
     */
    public void releasePhysicsWorld()
    {
        ballBody = null;
        if (wallBody != null)
        {
            for (int i = 0; i < wallBody.length; i++)
                wallBody[i] = null;
        }
        wallBody = null;
        worldAABBVisible = null;
        worldAABB = null;
        world = null;
    }
    
    public World getPhysicsWorld()
    {
        if (world != null)
            return world;
        
        // Physics World Boundaries
        worldAABB = new AABB(); 
        worldAABB.lowerBound.set(new Vec2((float) -5.0, (float) -5.0)); 
        worldAABB.upperBound.set(new Vec2((float) 5.0, (float) 5.0)); 
        world = new World(worldAABB, new Vec2(0.0f, -10.0f), false);
        world.setContinuousPhysics(true);
        
        float offset = (1.f - drawWalls) * wallThickness;
        Vec2 shrinkage = new Vec2(offset, offset);
        worldAABBVisible = new AABB();
        worldAABBVisible.lowerBound.set(worldAABB.lowerBound.add(shrinkage));
        worldAABBVisible.upperBound.set(worldAABB.upperBound.sub(shrinkage));
        
        // initialize walls
        {
            wallBody = new Body[4];
            BodyDef[] bd = new BodyDef[4]; 
            PolygonDef[] sd = new PolygonDef[4];
            for (int i = 0; i < 4; i++)
            {
                bd[i] = new BodyDef(); 
                sd[i] = new PolygonDef();
            }
            float width, height;
            
            // left/right walls
            width = wallThickness / 2;
            height = (worldAABB.upperBound.y - worldAABB.lowerBound.y - wallThickness) / 2;
            sd[0].setAsBox(width, height);
            sd[2].setAsBox(width, height);
            bd[0].position.set(worldAABB.lowerBound.x + width, worldAABB.upperBound.y - height);
            bd[2].position.set(worldAABB.upperBound.x - width, worldAABB.lowerBound.y + height);
            
            // bottom/top walls
            width = (worldAABB.upperBound.x - worldAABB.lowerBound.x - wallThickness) / 2;
            height = wallThickness / 2.5f;
            sd[1].setAsBox(width, height);
            sd[3].setAsBox(width, height);
            bd[1].position.set(worldAABB.lowerBound.x + width, worldAABB.lowerBound.y + height);
            bd[3].position.set(worldAABB.upperBound.x - width, worldAABB.upperBound.y - height);
            
            // common properties
            for (int i = 0; i < 4; i++) {
                sd[i].restitution = 0.67f;
                sd[i].density = 1.0f;
                wallBody[i] = world.createBody(bd[i]);
                wallBody[i].createShape(sd[i]);
            }
        }
        
        // Ball Physics
        {
            BodyDef bd = new BodyDef(); 
            CircleDef sd = new CircleDef();
            
            sd.radius = ballRadius;
            sd.density = 0.5f;
            bd.position.set(0.f, 0.f);
            
            ballBody = world.createBody(bd);
            ballBody.createShape(sd);
            ballBody.setMassFromShapes();
            ballBody.setUserData("Ball");
        }
        
        return world;
    }
    
    private float map(float point, float toLower, float toUpper, float fromLower, float fromUpper)
    {
        return toLower + (toUpper - toLower) * (point - fromLower) / (fromUpper - fromLower);
    }
    
    private float worldToScreenX(float x)
    {
        return map(x, 0, mBitmap.getWidth(), worldAABBVisible.lowerBound.x, worldAABBVisible.upperBound.x);
    }
    
    private float worldToScreenY(float y)
    {
        return map(y, mBitmap.getHeight(), 0, worldAABBVisible.lowerBound.y, worldAABBVisible.upperBound.y);
    }
    
    public void onDraw(Canvas canvas)
    {
        if (mBitmap == null || mCanvas == null)
            return;
        
        if (mBall == null)
        {
            mBall = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
        }
        
        // erase background
        Paint myPaint = new Paint();
        myPaint.setColor(0xFFDDDDDD);
        mBitmap.eraseColor(0);
        mCanvas.setBitmap(mBitmap);
        
        // draw ball
        Vec2 position = ballBody.getPosition();
        position.x = worldToScreenX(position.x);
        position.y = worldToScreenY(position.y);
        mCanvas.drawBitmap(mBall, position.x - mBall.getScaledWidth(mCanvas) / 2, position.y - mBall.getScaledHeight(mCanvas) / 2, myPaint);
        
        // Draw the walls (for debugging)
        if (drawWalls > 0.f)
        {
            Vec2 p1, p2;
            
            for (Body body = getPhysicsWorld().getBodyList(); body != null; body = body.getNext())
            {
                org.jbox2d.collision.Shape shape;
                for (shape = body.getShapeList(); shape != null; shape = shape.getNext())
                {
                    if (shape.getType() == ShapeType.POLYGON_SHAPE)
                    {
                        PolygonShape poly = (PolygonShape)shape;
                        int count = poly.getVertexCount();
                        Vec2[] verts = poly.getVertices();
                        
                        for(int i = 0; i < count - 1; i++)
                        {
                            p1 = body.getWorldPoint(verts[i]);
                            p2 = body.getWorldPoint(verts[i+1]);
                            mCanvas.drawLine(worldToScreenX(p1.x), worldToScreenY(p1.y), worldToScreenX(p2.x), worldToScreenY(p2.y), myPaint);
                        }
                        
                        // connect last point with first point
                        p1 = body.getWorldPoint(verts[verts.length - 1]);
                        p2 = body.getWorldPoint(verts[0]);
                        mCanvas.drawLine(worldToScreenX(p1.x), worldToScreenY(p1.y), worldToScreenX(p2.x), worldToScreenY(p2.y), myPaint);
                    }
                }
            }
        }
        
        // draw to screen
        canvas.drawBitmap(mBitmap, 0, 0, myPaint);
    }
    
    public void run()
    {
        synchronized(this)
        {
            if (!isPaused)
            {
                // update physics
                getPhysicsWorld().setGravity(gravity);
                getPhysicsWorld().step(timeStepSec * timeScale, iterations);
                
                // repaint
                invalidate();
                
                handler.postDelayed(this, (int)(timeStepSec * 1000));
            }
        }
    }
    
    public void pause()
    {
        synchronized(this)
        {
            isPaused = true;
            
            SensorManager sm = (SensorManager)getContext().getSystemService(android.content.Context.SENSOR_SERVICE);
            sm.unregisterListener(accelerometerListener);
        }
    }
    
    public void resume()
    {
        synchronized(this)
        {
            // set up accelerometer listener
            SensorManager sm = (SensorManager)getContext().getSystemService(android.content.Context.SENSOR_SERVICE);
            Sensor s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sm.registerListener(accelerometerListener, s, SENSOR_DELAY_FASTEST);
            
            isPaused = false;
        }
        
        handler.post(this);
    }
}
