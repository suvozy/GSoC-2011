/*
** =========================================================================
** Copyright (c) 2010-2011  Immersion Corporation.  All rights reserved.
**                          Immersion Corporation Confidential and Proprietary
**
** File:
**     BouncingBallSample.java
**
** Description: 
**     Sample Box2D application using UHL Launcher effects on collisions.
**
** =========================================================================
*/
package com.immersion.bouncingballsample;

import org.jbox2d.dynamics.ContactListener;
import org.jbox2d.dynamics.contacts.ContactPoint;
import org.jbox2d.dynamics.contacts.ContactResult;

import com.immersion.uhl.Launcher;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;

public class BouncingBallActivity extends Activity
{
    // range of physics parameters that trigger vibration feedback
    private static final float MIN_COLLISION_IMPULSE = 0.4f;
    private static final float MAX_COLLISION_IMPULSE = 8.0f;
    private static final long MIN_COLLISION_TIME = 50;
    
    private BouncingBallView m_view;
    private WakeLock m_wakelock;
    private Launcher m_launcher;        // to use built-in effects
    private long m_nextCollision;       // to reduce effect blurring
    private ContactListener m_contactListener = new ContactListener()
    {
        public void add(ContactPoint contactPoint) {}
        public void persist(ContactPoint contactPoint){}
        public void remove(ContactPoint contactPoint) {}
        public void result(ContactResult contactResult)
        {
            if (contactResult.normalImpulse >= MIN_COLLISION_IMPULSE)
            {
                long time = System.currentTimeMillis();
                
                // effects played too fast blur together
                if (time >= m_nextCollision)
                {
                    // choose a suitably strong collision effect
                    try
                    {
                        float strength = (contactResult.normalImpulse - MIN_COLLISION_IMPULSE) / (MAX_COLLISION_IMPULSE - MIN_COLLISION_IMPULSE);
                        if (strength < 0.33f)
                            m_launcher.play(Launcher.BOUNCE_33);
                        else if (strength < 0.67f)
                            m_launcher.play(Launcher.BOUNCE_66);
                        else
                            m_launcher.play(Launcher.BOUNCE_100);
                    }
                    catch (RuntimeException re) {}
                    
                    m_nextCollision = time + MIN_COLLISION_TIME;
                }
            }
        }
    };
    
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        m_view = (BouncingBallView)findViewById(R.id.bouncingballview);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);   
        m_wakelock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "DoNotDimScreen");   
        
        // initialize UHL vibration object
        try { m_launcher = new Launcher(this); }
        catch (RuntimeException re) {}
        
        m_nextCollision = 0;
        m_view.getPhysicsWorld().setContactListener(m_contactListener);
    }
    
    protected void onDestroy()
    {
        super.onDestroy();
        m_view.releasePhysicsWorld();
    }
    
    protected void onPause()
    {
        super.onPause();
        m_wakelock.release();
        m_view.pause();
        
        // stop vibration effect on application pause
        try { m_launcher.stop(); }
        catch (RuntimeException re) {}
    }
    
    protected void onResume()
    {
        super.onResume();
        m_view.resume();
        m_wakelock.acquire();
    }
}
