package com.example.myfirsthapicapp;

import com.immersion.uhl.Launcher;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MyFirstHapticAppActivity extends Activity {
	
	protected TextView mTxtOut;
	protected Launcher mLauncher;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mTxtOut = (TextView)findViewById(R.id.txtOut);
        
        try {
        	mLauncher = new Launcher(this);
        } catch (Exception e) {
        	Log.e("My App", "Exception!: " + e.getMessage());
        }

    }
    
    @Override
    public void onDestroy() {
    	super.onDestroy();
    }
    
    public void btnPlayEffectClicked(View view) {    	
    	mTxtOut.setText("Playing built-in effect:\n. Effect: DOUBLE_STRONG_CLICK_100.");
    	
    	try {
    	    mLauncher.play(Launcher.DOUBLE_STRONG_CLICK_100);
    	} catch (Exception e) {
    		mTxtOut.append("Error: " + e.getMessage());
    	}
    }
}